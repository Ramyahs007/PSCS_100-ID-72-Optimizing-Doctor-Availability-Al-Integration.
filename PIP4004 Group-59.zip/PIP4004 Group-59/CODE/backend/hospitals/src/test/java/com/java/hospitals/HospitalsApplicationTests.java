package com.java.hospitals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
