package com.java.hospitals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@SpringBootApplication
public class HospitalsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalsApplication.class, args);
	}

	@Bean
	public JavaMailSender javaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

		// Configure your mail sender properties (host, port, username, password, etc.)
		mailSender.setHost("smtp.gmail.com");  // Replace with your SMTP host
		mailSender.setPort(587);  // Replace with your SMTP port
		mailSender.setUsername("thalariramcharan459@gmail.com");  // Replace with your email username
		mailSender.setPassword("lygjgpttawbyuoad");  // Replace with your email password

		// Additional properties for TLS (you may need to customize based on your provider)
		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.debug", "true");  // Enable debugging for troubleshooting

		return mailSender;
	}

}
