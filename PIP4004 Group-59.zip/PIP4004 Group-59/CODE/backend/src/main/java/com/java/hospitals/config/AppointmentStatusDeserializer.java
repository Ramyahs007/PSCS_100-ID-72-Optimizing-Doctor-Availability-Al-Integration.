package com.java.hospitals.config;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.java.hospitals.model.AppointmentStatus;

import java.io.IOException;

public class AppointmentStatusDeserializer extends JsonDeserializer<AppointmentStatus> {

    @Override
    public AppointmentStatus deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        JsonNode node = p.getCodec().readTree(p);
        String statusValue = node.asText();

        for (AppointmentStatus status : AppointmentStatus.values()) {
            if (status.toString().equalsIgnoreCase(statusValue)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Invalid AppointmentStatus: " + statusValue);
    }
}

