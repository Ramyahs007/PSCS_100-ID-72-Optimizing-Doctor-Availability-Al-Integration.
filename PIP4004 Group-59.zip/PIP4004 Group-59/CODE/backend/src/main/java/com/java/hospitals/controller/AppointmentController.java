package com.java.hospitals.controller;

import com.java.hospitals.model.AppointmentStatus;
import com.java.hospitals.model.*;
import com.java.hospitals.repository.IAppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/appointment")
@CrossOrigin("*")
public class AppointmentController
{
    @Autowired
    private IAppointmentRepository repository;

    @PostMapping("/schedule")
    private ResponseEntity<?> scheduleAppointment(@RequestBody Appointment appointment) {
        HashMap<String, Object> res = new HashMap<>();
        try {
            // Create a new Appointment object
            Appointment appointment1 = new Appointment();
            appointment1.setDoctorId(appointment.getDoctorId());
            appointment1.setPatientId(appointment.getPatientId());
            appointment1.setDoctorName(appointment.getDoctorName());
            appointment1.setPatientName(appointment.getPatientName());
            appointment1.setProblem(appointment.getProblem());
            appointment1.setAppointmentDate(appointment.getAppointmentDate());
            appointment1.setStatus(appointment.getStatus());
            appointment1.setAttended(false);

            // Save the single Appointment object
            Appointment savedAppointment = repository.save(appointment);

            res.put("Success",true);
            res.put("msg","Appointment Created Successfully");

            return ResponseEntity.status(HttpStatus.CREATED).body(savedAppointment);
        } catch (Exception e) {
            // Handle exceptions and return an appropriate response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An unexpected error occurred while scheduling the appointment");
        }
    }

    @GetMapping("/patient/{patientId}")
    public ResponseEntity<?> getAppointmentByPatientId(@PathVariable Long patientId) {
        try {

            List<Appointment> appointments = repository.findByPatientId(patientId);

            if (appointments != null) {
                return ResponseEntity.ok(appointments);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Appointment not found");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An unexpected error occurred while fetching the appointment");
        }
    }

    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<?> getAppointmentByDoctorId(@PathVariable Long doctorId) {
        try {
            // Retrieve the appointment by ID
            List<Appointment> appointments = repository.findByDoctorId(doctorId);

            if (appointments != null) {
                return ResponseEntity.ok(appointments);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Appointment not found");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(e.getMessage());
        }
    }

    @PutMapping("/status/{id}")
    private ResponseEntity<?> statusChange(@PathVariable Long id, @RequestBody Appointment appointment) {
        try {
            Optional<Appointment> existingAppointment = repository.findById(id);
            if(existingAppointment.isEmpty()){
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("msg","Appointment is not found for provided id"+id));
            }

            // Update the properties of the existing appointment with the new values
            existingAppointment.get().setStatus(appointment.getStatus());

            if(appointment.getStatus()==AppointmentStatus.COMPLETED){
                existingAppointment.get().setAttended(true);
            }
            else {
                existingAppointment.get().setAttended(false);
            }

            // Save the updated appointment
            Appointment updatedAppointment = repository.save(existingAppointment.get());

            return ResponseEntity.ok(updatedAppointment);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An unexpected error occurred while updating the appointment");
        }
    }


    @PutMapping("/{id}")
    private ResponseEntity<?> updateAppointment(@PathVariable Long id, @RequestBody Appointment appointment) {
        try {
            Appointment existingAppointment = repository.getById(id);

            // Update the properties of the existing appointment with the new values
            appointment.setPatientId(existingAppointment.getPatientId());
            appointment.setPatientName(existingAppointment.getPatientName());
            appointment.setDoctorId(existingAppointment.getDoctorId());
            appointment.setDoctorName(existingAppointment.getDoctorName());
            appointment.setProblem(existingAppointment.getProblem());
            appointment.setAppointmentDate(existingAppointment.getAppointmentDate());
            appointment.setStatus(existingAppointment.getStatus());
            appointment.setAttended(existingAppointment.isAttended());

            // Save the updated appointment
            Appointment updatedAppointment = repository.save(appointment);

            return ResponseEntity.ok(updatedAppointment);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An unexpected error occurred while updating the appointment");
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAppointment(@PathVariable Long id) {
        try {
            // Check if the appointment exists
            if (repository.existsById(id)) {
                // Delete the appointment
                repository.deleteById(id);
                return ResponseEntity.ok("Appointment deleted successfully");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Appointment not found");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An unexpected error occurred while deleting the appointment");
        }
    }
}
