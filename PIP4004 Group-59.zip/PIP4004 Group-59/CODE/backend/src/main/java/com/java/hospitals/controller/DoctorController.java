package com.java.hospitals.controller;

import com.java.hospitals.dto.DoctorDTO;
import com.java.hospitals.model.ChangePasswordRequest;
import com.java.hospitals.model.Doctor;
import com.java.hospitals.model.Hospital;
import com.java.hospitals.repository.IDoctorRepository;
import com.java.hospitals.service.IDoctorService;
import io.micrometer.common.util.StringUtils;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@RequestMapping("/doctor")
@CrossOrigin("*")
@RequiredArgsConstructor
public class DoctorController
{
    @Autowired
    private IDoctorRepository repository;

    @Autowired
    private IDoctorService service;

    @Autowired
    private JavaMailSender javaMailSender;

    private Logger logger ;

    @PostMapping("/register")
    public ResponseEntity<?> addDoctor(@RequestBody DoctorDTO doctorRequest) {
        HashMap<String, Object> res = new HashMap<>();
        try {
            Doctor checkDoctor = repository.findByEmail(doctorRequest.getEmail());

            if (checkDoctor == null) {
                Doctor doctor = new Doctor(
                        doctorRequest.getHospitalName(),
                        doctorRequest.getName(),
                        doctorRequest.getEmail(),
                        doctorRequest.getPassword(),
                        doctorRequest.getQualification(),
                        doctorRequest.getSpecialization(),
                        doctorRequest.getPhoneNumber(),
                        doctorRequest.getAddress());

                repository.save(doctor);
                sendEmail(doctorRequest.getEmail(), "New Doctor is Added",
                        "Dear " + doctorRequest.getName() + ",\n\nWelcome to our "+doctorRequest.getHospitalName()+"!" +"You have been added as a doctor in our hospital. Your login credentials are:\nEmail: "
                                + doctorRequest.getEmail() + "\nPassword: " + doctorRequest.getPassword()
                                + "\n\nPlease keep this information secure.\n\nBest regards,\nThe Hospital Organization");

                res.put("success", true);
                res.put("msg", "Doctor Added Successfully");
            } else {
                res.put("success", false);
                res.put("msg", "Doctor Already Exists");
            }
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            res.put("success", false);
            res.put("msg", "Failed to Add doctor");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(res);
        }
    }

    private void sendEmail(String to, String subject, String body) {
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setTo(to);
        mailMessage.setSubject(subject);
        mailMessage.setText(body);

        javaMailSender.send(mailMessage);
    }

    @PostMapping("/login")
    public ResponseEntity<?> doctorLogin(@RequestBody HashMap<String, String> login) {
        HashMap<String, Object> res = new HashMap<>();
        try {
            String email = login.get("email");
            String password = login.get("password");

            if (StringUtils.isBlank(email) || StringUtils.isBlank(password)) {
                throw new IllegalArgumentException("Email and password are required fields");
            }

            Doctor doctor = repository.findByEmailAndPassword(email, password);

            if (doctor != null) {
                res.put("success", true);
                res.put("msg", "Login Successful");

                // Consider using a DTO to control what information is returned to the client
                DoctorDTO doctorDTO = new DoctorDTO();
                // Map relevant attributes from doctor entity to DTO
                doctorDTO.setId(doctor.getId());
                doctorDTO.setHospitalName(doctor.getHospitalName());
                doctorDTO.setName(doctor.getName());
                doctorDTO.setEmail(doctor.getEmail());
                doctorDTO.setPassword(doctor.getPassword());
                doctorDTO.setQualification(doctor.getQualification());
                doctorDTO.setSpecialization(doctor.getSpecialization());
                doctorDTO.setPhoneNumber(doctor.getPhoneNumber());
                doctorDTO.setAddress(doctor.getAddress());

                res.put("doctor", doctorDTO);

                return ResponseEntity.ok(res);
            } else {
                return new ResponseEntity<>("Invalid Credentials", HttpStatus.UNAUTHORIZED);
            }
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (EntityNotFoundException e) {
            return new ResponseEntity<>("Doctor with provided email and password not found", HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            // Log the detailed error message for debugging purposes
            logger.log(Level.SEVERE, "An error occurred during doctor login: " + e.getMessage(), e);
            return new ResponseEntity<>("An unexpected error occurred during doctor login", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    private ResponseEntity<?> getDoctorById(@PathVariable Long id){
        HashMap<String,Object> res = new HashMap<>();
        try{
            Doctor doctor = repository.findById(id).get();
            res.put("Success","True");
            res.put("Doctor",doctor);
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("Success","False");
            res.put("msg","Doctor is not Found for the provided id is"+id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
        }
    }

    @GetMapping("/hospital/name")
    private ResponseEntity<?> getDoctorsByHospitalName(@RequestParam String hospitalName){
        HashMap<String,Object> res = new HashMap<>();
        try{
            List<Doctor> doctors = repository.getDoctorsByHospitalName(hospitalName);
            res.put("Success","True");
            res.put("Doctor",doctors);
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("Success","False");
            res.put("msg","Doctors is not Found for the provided hospital name is"+hospitalName);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
        }
    }

    @GetMapping("/specialization")
    private ResponseEntity<?> getDoctorBySpecialization(@RequestParam String specialization){
        HashMap<String,Object> res = new HashMap<>();
        try{
            List<Doctor> doctor = repository.findDoctorBySpecialization(specialization);
            res.put("success",true);
            res.put("Doctors",doctor);
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("success",false);
            res.put("msg","No Doctors Found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
        }
    }

    @GetMapping
    private ResponseEntity<?> getAllDoctors(){
        HashMap<String,Object> res = new HashMap<>();
        try{
            List<Doctor> doctor = repository.findAll();
            res.put("success","true");
            res.put("Doctor",doctor);
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("success","false");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(res);
        }
    }

    @PutMapping("/doctor/{id}") // Specify the path variable
    private ResponseEntity<?> updateDoctor(@PathVariable Long id, @RequestBody Doctor updatedDoctor) {
        HashMap<String, Object> res = new HashMap<>();
        try {
            Optional<Doctor> existingDoctor = repository.findById(id); // Use Optional to handle possible null result

            if (existingDoctor.isPresent()) {
                Doctor doctor = existingDoctor.get();
                // Update the doctor's information with the data from the request
                doctor.setHospitalName(updatedDoctor.getHospitalName());
                doctor.setName(updatedDoctor.getName());
                doctor.setEmail(updatedDoctor.getEmail());
                doctor.setPassword(updatedDoctor.getPassword());
                doctor.setQualification(updatedDoctor.getQualification());
                doctor.setSpecialization(updatedDoctor.getSpecialization());
                doctor.setPhoneNumber(updatedDoctor.getPhoneNumber());
                doctor.setAddress(updatedDoctor.getAddress());

                repository.save(doctor);

                res.put("success", true);
                res.put("msg", "Doctor Updated Successfully");
                return ResponseEntity.ok(res);
            } else {
                res.put("success", false);
                res.put("msg", "Doctor not found with ID: " + id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
            }
        } catch (Exception e) {
            res.put("success", false);
            res.put("msg", "Failed to Update the Doctor");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(res);
        }
    }


    @DeleteMapping("/{id}")
    private ResponseEntity<?> deleteDoctorById(@PathVariable Long id){
        HashMap<String,Object> res = new HashMap<>();
        try{
            repository.deleteById(id);
            res.put("success","true");
            res.put("msg","Doctor Deleted Successfully");
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("success","False");
            res.put("msg","Failed to delete the Doctor by provided id is"+id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
        }
    }

    @PostMapping("/change-password")
    public ResponseEntity<?> changePassword(@RequestBody ChangePasswordRequest request) {
        // Validate the request, authenticate the user, and check if the old password is correct
        Doctor doctor = service.authenticateDoctor(request.getEmail(), request.getOldPassword());

        if (doctor != null) {
            // Update the user's password with the new one
            service.changePassword(doctor, request.getNewPassword());
            return ResponseEntity.ok("Password changed successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials.");
        }
    }
}
