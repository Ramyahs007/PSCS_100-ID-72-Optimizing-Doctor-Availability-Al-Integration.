package com.java.hospitals.controller;

import com.java.hospitals.dto.HospitalDTO;
import com.java.hospitals.model.ChangePasswordRequest;
import com.java.hospitals.model.Hospital;
import com.java.hospitals.repository.IHospitalRepository;
import com.java.hospitals.service.IHospitalService;
import io.micrometer.common.util.StringUtils;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Optional;

@RestController
@RequestMapping("/hospital")
@CrossOrigin("*")
public class HospitalController
{
    @Autowired
    private IHospitalRepository hospitalRepository;

    @Autowired
    private IHospitalService service;


    @PostMapping("/register")
    public ResponseEntity<?> addHospital(@RequestBody Hospital hospital) {
        HashMap<String, Object> res = new HashMap<>();
        try {
            hospitalRepository.save(hospital);
            res.put("success", true);
            res.put("msg", "Hospital Added Successfully");
            return ResponseEntity.ok(res);
        } catch (Exception e) {
            res.put("success", false);
            res.put("msg", "Failed to Add the Hospital");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(res);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> hospitalLogin(@RequestBody HashMap<String, String> login) {
        try {
            String email = login.get("email");
            String password = login.get("password");

            if (StringUtils.isBlank(email) || StringUtils.isBlank(password)) {
                throw new IllegalArgumentException("Email and password are required fields");
            }

            Hospital hospital = service.findByEmailAndPassword(email, password);

            if (hospital != null) {
                HospitalDTO hospitalDTO = new HospitalDTO();
                hospitalDTO.setId(hospital.getId());
                hospitalDTO.setUsername(hospital.getUsername());
                hospitalDTO.setEmail(hospital.getEmail());
                hospitalDTO.setPassword(hospital.getPassword());
                hospitalDTO.setPhoneNumber(hospital.getPhoneNumber());
                hospitalDTO.setAddress(hospital.getAddress());

                return new ResponseEntity<>(hospitalDTO, HttpStatus.OK);
            }

            return new ResponseEntity<>("Invalid Credentials", HttpStatus.BAD_REQUEST);
        } catch (EntityNotFoundException e) {
            return new ResponseEntity<>("Hospital with provided email and password not found", HttpStatus.NOT_FOUND);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/change-password")
    public ResponseEntity<?> changePassword(@RequestBody ChangePasswordRequest request) {
        try {
            // Validate the request, authenticate the hospital, and check if the old password is correct
            Hospital hospital = service.authenticateHospital(request.getEmail(), request.getOldPassword());

            if (hospital != null) {
                // Update the hospital's password with the new one
                service.changePassword(hospital, request.getNewPassword());
                return ResponseEntity.ok("Password changed successfully.");
            } else {
                return new ResponseEntity<>("Invalid credentials.", HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("An unexpected error occurred during password change", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    private ResponseEntity<?> getHospitalById(@PathVariable Long id){
        HashMap<String,Object> res = new HashMap<>();
        try{
            Optional<Hospital> hospital = hospitalRepository.findById(id);
            res.put("success",true);
            res.put("Hospital",hospital);
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("success",false);
            res.put("Hospital","Failed to Retrieve the hospital details by id"+id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
        }
    }
}
