package com.java.hospitals.controller;

import com.java.hospitals.dto.PatientDTO;
import com.java.hospitals.model.ChangePasswordRequest;
import com.java.hospitals.model.Patient;
import com.java.hospitals.repository.IPatientRepository;
import com.java.hospitals.service.IPatientService;
import io.micrometer.common.util.StringUtils;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/patient")
@CrossOrigin("*")
public class PatientController
{
    @Autowired
    private IPatientRepository repository;

    @Autowired
    IPatientService service;

    @PostMapping("/register")
    private ResponseEntity<?> addPatient(@RequestBody Patient patient)
    {
        HashMap<String,Object> res = new HashMap<>();
        try{
            repository.save(patient);
            res.put("success","true");
            res.put("msg","Patient Added Successfully");
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("success","false");
            res.put("msg","Failed to Add the patient");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(res);
        }
    }

    @PostMapping("/login")
    private ResponseEntity<?> patientLogin(@RequestBody HashMap<String,String> login){
        HashMap<String,Object> res = new HashMap<>();
        try {
            String email = login.get("email");
            String password = login.get("password");

            if (StringUtils.isBlank(email) || StringUtils.isBlank(password)) {
                throw new IllegalArgumentException("Email and password are required fields");
            }

            Patient patient = repository.findByEmailAndPassword(email, password);

            res.put("success","true");
            res.put("msg","Login Successful");
            res.put("Patient",patient);

            if (patient != null) {
                // Consider using a DTO to control what information is returned to the client
                PatientDTO patientDTO = new PatientDTO();
                // Map relevant attributes from hospital entity to DTO
                patientDTO.setId(patient.getId());
                patientDTO.setName(patient.getName());
                patientDTO.setEmail(patient.getEmail());
                patientDTO.setPassword(patient.getPassword());
                patientDTO.setDateOfBirth(patient.getDateOfBirth());
                patientDTO.setGender(patient.getGender());
                patientDTO.setPhoneNumber(patient.getPhoneNumber());
                patientDTO.setAddress(patient.getAddress());

                return ResponseEntity.ok(res);
            }

            return new ResponseEntity<>("Invalid Credentials", HttpStatus.BAD_REQUEST);
        } catch (EntityNotFoundException e) {
            return new ResponseEntity<>("Patient with provided email and password not found", HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An unexpected error occurred during patient login", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    private ResponseEntity<?> getPatientById(@PathVariable Long id){
        HashMap<String,Object> res = new HashMap<>();
        try{
            Patient patient = repository.findById(id).get();
            res.put("Success","True");
            res.put("Doctor",patient);
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("Success","False");
            res.put("msg","Patient is not Found for the provided id is"+id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
        }
    }


    @GetMapping
    private ResponseEntity<?> getAllPatients(){
        HashMap<String,Object> res = new HashMap<>();
        try{
            List<Patient> patients = repository.findAll();
            res.put("success","true");
            res.put("Doctor",patients);
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("success","false");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(res);
        }
    }

    @PutMapping
    private ResponseEntity<?> updatePatient(@RequestBody Patient patient){
        HashMap<String,Object> res = new HashMap<>();
        try{
            repository.save(patient);
            res.put("success","true");
            res.put("msg","Patient Updated Successfully");
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("success","False");
            res.put("msg","Failed to Update the Patient");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(res);
        }
    }

    @DeleteMapping("/{id}")
    private ResponseEntity<?> deletePatientById(@PathVariable Long id){
        HashMap<String,Object> res = new HashMap<>();
        try{
            repository.deleteById(id);
            res.put("success","true");
            res.put("msg","Patient Deleted Successfully");
            return ResponseEntity.ok(res);
        }
        catch(Exception e)
        {
            res.put("success","False");
            res.put("msg","Failed to delete the patient by provided id is"+id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(res);
        }
    }

    @PostMapping("/change-password")
    public ResponseEntity<?> changePassword(@RequestBody ChangePasswordRequest request) {
        // Validate the request, authenticate the user, and check if the old password is correct
        Patient patient = service.authenticatePatient(request.getEmail(), request.getOldPassword());

        if (patient != null) {
            // Update the user's password with the new one
            service.changePassword(patient, request.getNewPassword());
            return ResponseEntity.ok("Password changed successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials.");
        }
    }

}
