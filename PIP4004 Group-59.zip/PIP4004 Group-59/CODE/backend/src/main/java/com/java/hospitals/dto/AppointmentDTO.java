package com.java.hospitals.dto;

import com.java.hospitals.model.AppointmentStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentDTO
{
    private Long id;

    private Long patientId;

    private Long doctorId;

    private String doctorName;

    private String patientName;

    private String appointmentDate;

    private String problem;

    private AppointmentStatus status;

    private boolean attended;
}
