package com.java.hospitals.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DoctorDTO
{
    private Long id;
    private String hospitalName;
    private String name;
    private String email;
    private String password;
    private String qualification;
    private String specialization;
    private String phoneNumber;
    private String address;
}
