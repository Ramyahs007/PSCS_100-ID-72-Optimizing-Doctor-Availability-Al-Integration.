package com.java.hospitals.dto;

import com.java.hospitals.model.Doctor;
import jakarta.persistence.CascadeType;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HospitalDTO
{
    private Long id;
    private String username;
    private String email;
    private String password;
    private String address;
    private String phoneNumber;
}
