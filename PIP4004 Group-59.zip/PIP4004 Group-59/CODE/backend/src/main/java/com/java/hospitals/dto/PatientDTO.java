package com.java.hospitals.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PatientDTO
{
    private Long id;
    private String name;
    private String email;
    private String password;
    private String address;
    private String phoneNumber;
    private String dateOfBirth;
    private String gender;
}
