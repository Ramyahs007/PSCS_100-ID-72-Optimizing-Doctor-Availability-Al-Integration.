package com.java.hospitals.model;

public enum AppointmentStatus
{
    PENDING,
    SCHEDULED,
    COMPLETED,
    CANCEL;

}
