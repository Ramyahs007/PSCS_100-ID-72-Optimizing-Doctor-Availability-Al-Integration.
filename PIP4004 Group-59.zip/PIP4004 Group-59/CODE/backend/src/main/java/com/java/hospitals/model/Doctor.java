package com.java.hospitals.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Doctor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String hospitalName;
    private String name;
    private String email;
    private String password;
    private String qualification;
    private String specialization;
    private String phoneNumber;
    private String address;

    @ManyToMany
    private List<Appointment> appointments;


    public Doctor(String hospitalName, String name, String email, String password, String qualification, String specialization, String phoneNumber, String address)
    {
        this.hospitalName = hospitalName;
        this.name = name;
        this.email = email;
        this.password = password;
        this.qualification = qualification;
        this.specialization = specialization;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }
}

