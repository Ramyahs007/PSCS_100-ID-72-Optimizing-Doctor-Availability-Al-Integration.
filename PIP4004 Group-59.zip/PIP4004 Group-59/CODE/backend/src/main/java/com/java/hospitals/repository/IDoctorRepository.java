package com.java.hospitals.repository;

import com.java.hospitals.model.Doctor;
import com.java.hospitals.model.Hospital;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IDoctorRepository extends JpaRepository<Doctor,Long>
{
    List<Doctor> findDoctorBySpecialization(String specialization);

    Doctor findByEmail(String email);

    Doctor findByEmailAndPassword(String email, String password);

    List<Doctor> getDoctorsByHospitalName(String hospitalName);
}
