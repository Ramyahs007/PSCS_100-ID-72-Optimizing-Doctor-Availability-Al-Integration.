package com.java.hospitals.repository;

import com.java.hospitals.model.Hospital;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IHospitalRepository extends JpaRepository<Hospital,Long>
{
    Hospital findByEmailAndPassword(String email, String password);

    Hospital findByEmail(String email);
}
