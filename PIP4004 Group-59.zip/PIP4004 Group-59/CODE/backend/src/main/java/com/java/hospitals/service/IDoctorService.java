package com.java.hospitals.service;

import com.java.hospitals.model.Doctor;

public interface IDoctorService
{
    Doctor authenticateDoctor(String email,String password);

    void changePassword(Doctor doctor,String newPassword);
}
