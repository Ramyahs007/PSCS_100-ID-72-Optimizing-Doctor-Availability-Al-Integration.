package com.java.hospitals.service;

import com.java.hospitals.model.Hospital;

public interface IHospitalService {

    Hospital findByEmailAndPassword(String email, String password);
    Hospital authenticateHospital(String email, String password);
    void changePassword(Hospital hospital, String newPassword);
}
