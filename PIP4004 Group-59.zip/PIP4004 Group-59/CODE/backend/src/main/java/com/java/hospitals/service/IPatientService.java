package com.java.hospitals.service;

import com.java.hospitals.model.Patient;

public interface IPatientService
{
    Patient authenticatePatient(String email,String password);

    void changePassword(Patient patient,String newPassword);
}
