package com.java.hospitals.service.impl;

import com.java.hospitals.model.Doctor;
import com.java.hospitals.repository.IDoctorRepository;
import com.java.hospitals.service.IDoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DoctorService implements IDoctorService
{
    @Autowired
    private IDoctorRepository repository;

    @Override
    public Doctor authenticateDoctor(String email, String password)
    {
        Doctor doctor = repository.findByEmail(email);
        if (doctor != null) {
            return doctor;
        }
        return null;
    }

    @Override
    public void changePassword(Doctor doctor, String newPassword) {
        doctor.setPassword(newPassword);
        repository.save(doctor);
    }
}
