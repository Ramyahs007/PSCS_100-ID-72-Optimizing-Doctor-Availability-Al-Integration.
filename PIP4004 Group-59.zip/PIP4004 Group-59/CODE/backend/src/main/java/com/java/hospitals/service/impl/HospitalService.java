package com.java.hospitals.service.impl;

import com.java.hospitals.model.Hospital;
import com.java.hospitals.repository.IHospitalRepository;
import com.java.hospitals.service.IHospitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HospitalService implements IHospitalService {

    @Autowired
    private IHospitalRepository repository;

    @Override
    public Hospital findByEmailAndPassword(String email, String password) {
        return repository.findByEmailAndPassword(email,password);
    }

    @Override
    public Hospital authenticateHospital(String email, String password) {
        Hospital hospital = repository.findByEmail(email);

        if (hospital != null) {
            return hospital;
        }
        return null;
    }

    @Override
    public void changePassword(Hospital hospital, String newPassword) {
        hospital.setPassword(newPassword);
        repository.save(hospital);
    }
}
