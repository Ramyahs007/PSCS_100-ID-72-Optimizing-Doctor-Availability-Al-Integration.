package com.java.hospitals.service.impl;

import com.java.hospitals.model.Patient;
import com.java.hospitals.repository.IPatientRepository;
import com.java.hospitals.service.IPatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatientService implements IPatientService {

    @Autowired
    private IPatientRepository repository;

    @Override
    public Patient authenticatePatient(String email, String password) {
        Patient patient = repository.findByEmail(email);
        if(patient != null)
        {
            return patient;
        }
        return null;
    }

    @Override
    public void changePassword(Patient patient, String newPassword) {

        patient.setPassword(newPassword);
        repository.save(patient);

    }
}
