import './App.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './component/Login'
import Register from './component/Register'
import Hospital from './component/Hospital';
import Main from './component/Main';
import Appointment from './component/Appointment';
import ForgotPassword from './component/forgotPassword'
import Home from './component/hospital/home';
import Doctor from './component/hospital/Doctor';
import View from './component/hospital/View';
import Udoctor from './component/hospital/uDoctor';
import { Toaster } from 'react-hot-toast';
import DoctorHome from './component/doctor/DoctorHome';
import PatientHome from './component/patient/PatientHome';
import ViewAppointments from './component/patient/ViewAppointments';
import ViewAppointmentsDoctor from './component/doctor/ViewAppointmentsDoctor';

function App() {

  return (
    <div>
      <Router>
        <Routes>
          <Route path="/" element={<Main/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/register" element={<Hospital/>}/>          
          <Route path="/pRegister" element={<Register/>} />
          <Route path="/appointment" element={<Appointment/>} />
          <Route path="/appointment/:name/:id" element={<Appointment/>} />
          <Route path="/changePassword" element={<ForgotPassword/>} />
          <Route path="/home" element={<Home/>} />
          <Route path="/addDoctor" element={<Doctor/>} />
          <Route path="/viewDoctors" element={<View/>} />
          <Route path="/updateDoctor/:id" element={<Udoctor/>} />

          <Route path='/dhome' element={<DoctorHome/>}/>
          <Route path='/viewappointment' element={<ViewAppointmentsDoctor/>}/>
          <Route path='/phome' element={<PatientHome/>}/>
          <Route path='/booked' element={<ViewAppointments/>}/>
        </Routes>  
      </Router>
      <Toaster/>
    </div>
  )
}

export default App
