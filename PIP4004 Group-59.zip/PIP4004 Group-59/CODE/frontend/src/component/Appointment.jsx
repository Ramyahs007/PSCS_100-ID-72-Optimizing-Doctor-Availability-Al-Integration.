import React, { useEffect } from "react";
import "../component/component.css";
import { useNavigate, useParams } from "react-router-dom";
import PatientNavbar from "./patient/PatientNavbar";
import AxiosApi from "./AxiosApi";
import {useForm} from "react-hook-form";
import { toast} from "react-hot-toast"
const Appointment = () => {
  const {name}=useParams();
  const {id}=useParams();
  const appointmentForm=useForm();
  const navigateTo=useNavigate();
  const pid=localStorage.getItem("pId");
  const pName= localStorage.getItem("pName")
  const bookAppointmentFunction=async(data)=>{
  
   try {
    await AxiosApi.post(`/appointment/schedule`, data).then((response)=>{
      console.log(response, "apposs");
      response.status===201&& toast.success("Appointment booked")&&navigateTo("/booked")
    })
   } catch (error) {
    
    console.log(error, "appo");
   }
console.log(data, "appo");
  }
  
  return (<div>
    <PatientNavbar/>

    <div className="wrapper">
      <div className="text-center mt-4 name">APPOINTMENT</div>
      <form className="p-3 mt-3" onSubmit={appointmentForm.handleSubmit(bookAppointmentFunction)}>
        <div className="form-field d-flex align-items-center">
          <span className="far fa-user" />
          <input
            type="text"
            name="patientName"
            id="patientName"
            placeholder="Enter your name"
            value={pName}
            {
            ...appointmentForm.register("patientName")
            }
          />
           <input
            type="hidden"
            name="patientId"
            id="patientId"
           value={pid}
            {
            ...appointmentForm.register("patientId")
            }
          />
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="far fa-user" />
          <input
            type="text"
            name="doctorName"
            id="doctorName"
            placeholder="Enter your doctor name"
            value={name}
            {
              ...appointmentForm.register("doctorName")
              }
          />
           <input
            type="hidden"
            name="doctorId"
            id="doctorId"
           value={id}
            {
            ...appointmentForm.register("doctorId")
            }
          />
        </div>
        <p className="text-muted">(Appointment Date)</p>
        <div className="form-field d-flex align-items-center">
          <span className="fas fa-key" />
          <input
            type="date"
            name="appointmentDate"
            id="appointmentDate"
            placeholder=""
            {
              ...appointmentForm.register("appointmentDate")
              }
          />
         
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="far fa-user" />
          <input
            type="text"
            name="problem"
            id="problem"
            placeholder="Enter Current Health Issues"
            {
              ...appointmentForm.register("problem")
              }
          />
        </div>
        {/* <div className="form-field d-flex align-items-center">
          <span className="far fa-user" />
          <select
            name="appointmentStatus"
            id="appointmentStatus"
            className="form-select"
            defaultValue="" // Set the default selected value here
          >
            <option value="" disabled>
              Select appointment status
            </option>
            <option value="PENDING">PENDING</option>
            <option value="CONFIRMED">CONFIRMED</option>
            <option value="COMPLETED">COMPLETED</option>
            <option value="CANCELLED">CANCEL</option>
          </select>
        </div>
        <div class="form-check form-switch">
          <input
            class="form-check-input"
            type="checkbox"
            role="switch"
            id="flexSwitchCheckDefault"
          />
          <label class="form-check-label" for="flexSwitchCheckDefault">
            Attended
          </label>
        </div> */}
        <button className="btn mt-3">BOOK</button>
      </form>
    </div></div>
  );
};

export default Appointment;
