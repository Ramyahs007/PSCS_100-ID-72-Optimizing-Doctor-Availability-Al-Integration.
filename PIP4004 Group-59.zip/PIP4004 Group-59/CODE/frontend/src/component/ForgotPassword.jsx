import React from 'react'
import "../component/component.css";

const ForgotPassword = () => {
  return (
    <div className="wrapper">
      <div className="text-center mt-4 name">Forgot Password</div>
      <form className="p-3 mt-3">
        <div className="form-field d-flex align-items-center">
          <span className="far fa-user" />
          <input
            type="email"
            name="email"
            id="email"
            placeholder="Enter your Email"
          />
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="far fa-user" />
          <input
            type="password"
            name="oldPassword"
            id="oldPassword"
            placeholder="Enter your Old Password"
          />
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="fas fa-key" />
          <input
            type="password"
            name="newPassword"
            id="newPassword"
            placeholder="enter your new password"
          />
        </div>
          <button className="btn mt-3">change password</button>
      </form>
    </div>
  )
}

export default ForgotPassword
