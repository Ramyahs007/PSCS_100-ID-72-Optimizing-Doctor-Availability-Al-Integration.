import React, { useState } from "react";
import axios, { Axios } from "axios";
import "../component/component.css";
import { Link, useNavigate } from "react-router-dom";
import { toast, Toaster } from "react-hot-toast";
import AxiosApi from "./AxiosApi";

const Hospital = () => {
  const navigateTo=useNavigate()
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    phoneNumber: "",
    address: "",
  });

  const [formErrors, setFormErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setFormErrors({ ...formErrors, [name]: "" });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate the form fields before submitting
    const errors = {};
    if (!formData.username.trim()) {
      errors.username = "Hospital name is required.";
    }
    if (!formData.email.trim()) {
      errors.email = "Email is required.";
    }
    if (!formData.password.trim()) {
      errors.password = "Password is required.";
    } else if (formData.password.length < 6) {
      errors.password = "Password should be at least 6 characters.";
    }
    if (!formData.phoneNumber.trim()) {
      errors.phoneNumber = "Phone number is required.";
    }
    if (!formData.address.trim()) {
      errors.address = "Address is required.";
    }

    if (Object.keys(errors).length === 0) {
      AxiosApi
        .post("/hospital/register", formData)
        .then((response) => {
          if (response.data.success === true) {
            toast.success("Hopital Registered Successfully");
            navigateTo("/")
          } else {
            toast.error(response.data.msg);
          }
        })
        .catch((error) => {
          console.log(error);
          toast.error("An error occurred while adding the Hospital.");
        });
    } else {
      setFormErrors(errors);
    }
  };

  return (
    <div className="pics">
      <div className="wrapper">
        <div className="text-center mt-4 name">Hospital Register</div>
        <form className="p-3 mt-3" onSubmit={handleSubmit}>
          <div className="form-field d-flex align-items-center">
            <span className="far fa-user" />
            <input
              type="text"
              name="username"
              id="username"
              placeholder="Enter your hospital name"
              value={formData.username}
              onChange={handleChange}
            />
          </div>
          {formErrors.username&&<p className="text-danger">{formErrors.username}</p>}

          <div className="form-field d-flex align-items-center">
            <span className="far fa-user" />
            <input
              type="email"
              name="email"
              id="email"
              placeholder="enter your email"
              value={formData.email}
              onChange={handleChange}
            />
          </div>
          {formErrors.email&&<p className="text-danger">{formErrors.email}</p>}

          <div className="form-field d-flex align-items-center">
            <span className="fas fa-key" />
            <input
              type="password"
              name="password"
              id="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
            />
          </div>
          {formErrors.password&&<p className="text-danger">{password.email}</p>}

          <div className="form-field d-flex align-items-center">
            <span className="fas fa-key" />
            <input
              type="number"
              size={10}
              name="phoneNumber"
              id="phoneNumber"
              placeholder="Enter your mobile Number"
              value={formData.phoneNumber}
              onChange={handleChange}
            />
          </div>
          {formErrors.phoneNumber&&<p className="text-danger">{formErrors.phoneNumber}</p>}

          <div className="form-field d-flex align-items-center">
            <span className="far fa-user" />
            <input
              type="text"
              name="address"
              id="address"
              placeholder="Enter your address"
              value={formData.address}
              onChange={handleChange}
            />
          </div>
          {formErrors.address&&<p className="text-danger">{formErrors.address}</p>}

          <button className="btn mt-3">Register</button> or{" "}
          <Link to="/login">Login</Link>
        </form>
      </div>
    </div>
  );
};

export default Hospital;
