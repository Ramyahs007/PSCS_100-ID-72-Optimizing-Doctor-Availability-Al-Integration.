import React, { useState } from 'react';
import "../component/component.css";
import { Link, useNavigate } from 'react-router-dom';
import AxiosApi from './AxiosApi';
import {useForm} from "react-hook-form"
import toast from 'react-hot-toast';

const Login = () => {
  const [name, setName]=useState();
  const loginForm=useForm()
  const navigateTo =useNavigate();
  const changeName=(e)=>{
setName(e.target.value)
  }
  const loginFunction= async(data)=>{
    try {
      if (name==="HOSPITAL") {
     const reslog=  await AxiosApi.post("/hospital/login", data);
     localStorage.setItem("hId", reslog.data.id);
     localStorage.setItem("hospitalName", reslog.data.username)
    reslog.status===200&& toast.success("Login Successfull")&&navigateTo(`/home`)
     console.log(reslog, "login succ");
      }
      else if (name==="PATIENT") {
        const reslog1=  await AxiosApi.post("/patient/login", data);
        console.log(reslog1, "userData");
        localStorage.setItem("pId", reslog1.data.Patient.id);
        localStorage.setItem("pName",reslog1.data.Patient.name)
       reslog1.status===200&& toast.success("Login Successfull")&&navigateTo(`/phome`)
        console.log(reslog1, "login succ");
         }
         else if (name==="DOCTOR") {
          const reslog12=  await AxiosApi.post("/doctor/login", data);
          localStorage.setItem("dId", reslog12.data.doctor.id);
         reslog12.status===200&& toast.success("Login Successfull")&&navigateTo(`/dhome`)
          console.log(reslog12, "login succ");
           }

    } catch (error) {
      console.log(error.response.data, "login error");
      toast.error(error.response.data);
    }
  }
  return (
    <div className="wrapper">
        <div>
          <select onChange={changeName} required >
          
            <option value="">SELECT LOGIN</option>
            <option value="HOSPITAL">HOSPITAL</option>
            <option value="PATIENT">PATIENT</option>
            <option value="DOCTOR">DOCTOR</option>
          </select>
        </div>
        <div className="logo" style={{marginLeft:"100px"}}>
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQxRmDlW14dXAjqaVHzWdJrcIgtN--ABHMuXQ&usqp=CAU" alt="" />
        </div>
        
        <div className="text-center mt-4 name">
          {name}
        </div>
        <form className="p-3 mt-3" onSubmit={loginForm.handleSubmit(loginFunction)}>
          <div className="form-field d-flex align-items-center">
            <span className="far fa-user" />
            <input type="email" name="email" id="email" placeholder="enter your email"
            {...loginForm.register("email")}
             />
          </div>
          <div className="form-field d-flex align-items-center">
            <span className="fas fa-key" />
            <input type="password" name="password" id="password" placeholder="Password" 
            {...loginForm.register("password")}
            
            />
          </div>
          <button className="btn mt-3" type='submit'>Login</button>
        </form>
        <div className="text-center fs-6">
          <a href="#"><Link to="/changePassword">Forget password?</Link></a> or <Link to="/">Sign up</Link>
        </div>
      </div>
    );
  }

export default Login
