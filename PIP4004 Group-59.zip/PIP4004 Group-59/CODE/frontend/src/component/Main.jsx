import React from "react";
import "./component.css"
import { Link } from "react-router-dom";
import Footer from "./Footer";


const MainNavbar = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light fixed-top" style={{height:"90px"}}>
        <div className="container">
            OPTIMIZING DOCTOR AVAILABLE
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarResponsive"
            aria-controls="navbarResponsive"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>
          <div className="collapse navbar-collapse" id="navbarResponsive">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item active">
                <Link to="/" className="nav-link">HOME</Link>
              </li>
              <li className="nav-item dropdown">
                <Link
                  className="nav-link dropdown-toggle-primary"
                  href="#"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  REGISTER
                </Link>
                <ul className="dropdown-menu">
                  <li>
                      <Link to="/register" className="dropdown-item">HOSPITAL</Link>
                  </li>
                  <li>
                      <Link to ="/pRegister" className="dropdown-item">PATIENT</Link>
                  </li>
                </ul>
              </li>
              <li className="nav-item active">
                  <Link to="/login" className="nav-link">LOGIN</Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <header>
        <div id="carouselExampleCaptions" className="carousel slide">
          <div className="carousel-indicators">
            <button
              type="button"
              data-bs-target="#carouselExampleCaptions"
              data-bs-slide-to="0"
              className="active"
              aria-current="true"
              aria-label="Slide 1"
            ></button>
            <button
              type="button"
              data-bs-target="#carouselExampleCaptions"
              data-bs-slide-to="1"
              aria-label="Slide 2"
            ></button>
            <button
              type="button"
              data-bs-target="#carouselExampleCaptions"
              data-bs-slide-to="2"
              aria-label="Slide 3"
            ></button>
          </div>
          <div className="carousel-inner">
            <div className="carousel-item active mt-5 " style={{width:"100%", height:"100vh"}} >
              <img 
                src="/hosp.jpg"
                className="d-block w-100 h-100"
                alt=""
              />
            </div>
            <div className="carousel-item">
              <img
                src="https://www.piramalrevanta.com/wp-content/uploads/2022/09/20220906-article-banner-01.jpg"
                className="d-block w-100 h-100" style={{width:"100%", height:"100vh"}}
                alt=""
              />
            </div>
            <div className="carousel-item">
              <img  style={{width:"100%", height:"100vh"}}
                src="https://www.brookings.edu/wp-content/uploads/2017/05/hospital002.jpg?w=1500"
                className="d-block w-100 h-100"
                alt=""
              />
            </div>
          </div>
          <button
            className="carousel-control-prev"
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev"
          >
            <span
              className="carousel-control-prev-icon"
              aria-hidden="true"
            ></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button
            className="carousel-control-next"
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next"
          >
            <span
              className="carousel-control-next-icon"
              aria-hidden="true"
            ></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </header>

      <Footer/>
    </div>
  );
};

export default MainNavbar;
