import React, { useState } from "react";
import axios from "axios";
import "../component/component.css";
import { Link, useNavigate } from "react-router-dom";
import { toast, Toaster } from "react-hot-toast";
import AxiosApi from "./AxiosApi";

const Register = () => {
  const navigatedTo=useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    dateOfBirth: "",
    gender: "",
    phoneNumber: "",
    address: "",
  });

  const [formErrors, setFormErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    setFormData({ ...formData, [name]: value });
    setFormErrors({ ...formErrors, [name]: "" });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate the form fields before submitting
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = "patient name is required.";
    }
    if (!formData.email.trim()) {
      errors.email = "Email is required.";
    }
    if (!formData.password.trim()) {
      errors.password = "Password is required.";
    } else if (formData.password.length < 6) {
      errors.password = "Password should be at least 6 characters.";
    }
    if (!formData.dateOfBirth.trim()) {
      errors.dateOfBirth = "date of birth is required.";
    }
    if (!formData.gender.trim()) {
      errors.gender = "gender is required";
    }
    if (!formData.phoneNumber.trim()) {
      errors.phoneNumber = "Phone number is required.";
    }
    if (!formData.address.trim()) {
      errors.address = "Address is required.";
    }

    console.log(errors,"errors");
    console.log(formData,"data");

    if (Object.keys(errors).length === 0) {
      AxiosApi
        .post("/patient/register", formData)
        .then((response) => {
          console.log(response, "badb");
          if (response.status === 200) {
            toast.success(response.data.msg);
            navigatedTo("/")
          } 
          
        })
        .catch((error) => {
          console.log(error, "regerr");
          toast.error("Failed to add the patient.");
        });
    } else {
      setFormErrors(errors);
    }
  };

  return (
    <div className="wrapper">
      <div className="text-center mt-4 name">Patient</div>
      <form className="p-3 mt-3" onSubmit={handleSubmit}>
        <div className="form-field d-flex align-items-center">
          <span className="far fa-user" />
          <input
            type="text"
            name="name"
            id="name"
            placeholder="Enter your name"
            value={formData.name}
            onChange={handleChange}
          />
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="far fa-user" />
          <input
            type="email"
            name="email"
            id="email"
            placeholder="enter your email"
            value={formData.email}
            onChange={handleChange}
          />
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="fas fa-key" />
          <input
            type="password"
            name="password"
            id="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
          />
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="fas fa-key" />
          <input
            type="date"
            name="dateOfBirth"
            id="dateOfBirth"
            placeholder="Enter your Date of Birth"
            value={formData.dateOfBirth}
            onChange={handleChange}
          />
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="mb-3 mr-1">Gender: </span>
          <input
            type="radio"
            className="btn-check"
            name="gender"
            id="male"
            autoComplete="off"
            value="male"
            checked={formData.gender==="male"}
            onChange={handleChange}
            required
          />
          <label className="btn btn-sm btn-outline-secondary" htmlFor="male">
            Male
          </label>
          <input
            type="radio"
            className="btn-check"
            name="gender"
            id="female"
            autoComplete="off"
            value="female"
            checked={formData.gender==="female"}
            onChange={handleChange}
            required
          />
          <label className="btn btn-sm btn-outline-secondary" htmlFor="female">
            Female
          </label>
          <div className="valid-feedback mv-up">You selected a gender!</div>
          <div className="invalid-feedback mv-up">Please select a gender!</div>
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="fas fa-key" />
          <input
            type="number"
            size={10}
            name="phoneNumber"
            id="phoneNumber"
            placeholder="Enter your mobile Number"
            value={formData.phoneNumber}
            onChange={handleChange}
          />
        </div>
        <div className="form-field d-flex align-items-center">
          <span className="far fa-user" />
          <input
            type="text"
            name="address"
            id="address"
            placeholder="Enter your address"
            value={formData.address}
            onChange={handleChange}
          />
        </div>
        <button className="btn mt-3" type="submit">Register</button> or{" "}
        <Link to="/login">Login</Link>
      </form>
    </div>
  );
};

export default Register;
