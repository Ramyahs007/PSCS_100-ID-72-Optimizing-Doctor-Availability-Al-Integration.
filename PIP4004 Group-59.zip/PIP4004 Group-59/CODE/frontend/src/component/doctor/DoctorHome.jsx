import React from 'react'
import DoctorNav from './DoctorNav'
import Footer from '../Footer'

const DoctorHome = () => {
  return (
    <div>
        <DoctorNav/>
        <img src="/doctor.jpg" alt="" width={"100%"} height={"100%"} />
        <Footer/>
    </div>
  )
}

export default DoctorHome