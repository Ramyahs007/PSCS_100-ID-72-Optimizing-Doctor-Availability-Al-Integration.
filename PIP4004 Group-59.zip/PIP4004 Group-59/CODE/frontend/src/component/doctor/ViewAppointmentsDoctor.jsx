import { Axios } from "axios";
import React, { useEffect, useState } from "react";
import AxiosApi from "../AxiosApi";
import DoctorNav from "./DoctorNav";
import toast from "react-hot-toast";

const ViewAppointmentsDoctor = () => {
  const id = localStorage.getItem("dId");
  const [docAppoinntments, setDocAppointments] = useState();
  const getAppointments = async () => {
    try {
      await AxiosApi.get(`/appointment/doctor/${id}`).then((response) => {
        console.log(response, "all appointments");
        setDocAppointments(response.data);
      });
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    getAppointments();
  }, []);
  const sendStatus=async(id, status)=>{
    try {
        await AxiosApi.put(`/appointment/status/${id}`, {"status":status}).then((response)=>{
            console.log(response,"bjhfdjkg");
            toast.success("updated successfully");
        })
    } catch (error) {
        console.log(error);
    }
  }
  const attendedFunc=async(id, attended)=>{
    try {
        await AxiosApi.put(`/appointment/${id}`, {"attended":attended}).then((response)=>{
            console.log(response,"bjhfdjkg");
        })
    } catch (error) {
        console.log(error);
    }
  }
  return (
    <div>
      <DoctorNav />
      <table
        className="table table-bordered table-info"
        style={{ marginTop: "100px" }}
      >
        <thead>
          <tr>
            <th colSpan={6}>All Appointments</th>
          </tr>
          <tr>
            <td>#</td>
            <td>Patient Name</td>
            <td>Health Issues</td>
            <td>Date</td>
            <td>Status</td>
            {/* <td>Attended</td> */}
          </tr>
        </thead>
        <tbody>
          {docAppoinntments &&
            docAppoinntments.map((item, index) => (
              <tr key={item.id}>
                <td>{index + 1}</td>
                <td>{item.patientName}</td>
                <td>{item.problem}</td>
                <td>{item.appointmentDate}</td>
                <td>
                  {" "}
                  <select
                    name="status"
                    id="status"
                    // className="form-select"
                    onChange={(e)=>sendStatus(item.id, e.target.value)}
                    defaultValue={item.status} // Set the default selected value here
                  >
                    <option value="" disabled>
                      Select
                    </option>
                    <option value={0}>PENDING</option>
                    <option value={1}>SCHEDULED</option>
                    <option value={2}>COMPLETED</option>
                    <option value={3}>CANCEL</option>
                  </select>
                </td>
                {/* <td>
                  Yes  <input type="radio" name={`attended_${item.id}`}   value={true} onChange={(e)=>attendedFunc(item.id, e.target.value)}/> &nbsp;
                  No  <input type="radio" name={`attended_${item.id}`}  value={false} onChange={(e)=>attendedFunc(item.id, e.target.value)}/>
                </td> */}
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewAppointmentsDoctor;
