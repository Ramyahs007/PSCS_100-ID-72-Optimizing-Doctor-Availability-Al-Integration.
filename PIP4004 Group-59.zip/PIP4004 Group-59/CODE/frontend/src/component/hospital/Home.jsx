import React from 'react'
import Navbar from './Navbar'
import Footer from '../Footer'

const Home = () => {
  return (
    <div>
        <Navbar/>
        <img src="/hospital.jpg" width={"100%"} height={"100%"}/>
        <Footer/>
    </div>
  )
}

export default Home
