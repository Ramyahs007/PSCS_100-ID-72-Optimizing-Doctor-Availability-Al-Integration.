import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg bg-body-tertiary fixed-top">
      <div className="container-fluid" style={{ height: "10px" }}>
        HOSPITAL
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarScroll"
          aria-controls="navbarScroll"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarScroll">
          <ul
            className="navbar-nav ml-auto my-2 p-2 navbar-nav-scroll ms-auto"
            style={{ "--bs-scroll-height": "100px;" }}
          >
            <li className="nav-item p-2 ">
              <Link to="/home" className="text-decoration-none text-dark">Home</Link>
            </li>
            <li className="nav-item p-2">
              <Link to="/addDoctor" className="text-decoration-none text-dark">Add Doctors</Link>
            </li>
            <li className="nav-item p-2">
            <Link to="/viewDoctors" className="text-decoration-none text-dark">View Doctors</Link>
            </li>
            <li className="nav-item p-2">
                <Link to="/login" className="text-decoration-none text-dark">Logout</Link>
                </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
