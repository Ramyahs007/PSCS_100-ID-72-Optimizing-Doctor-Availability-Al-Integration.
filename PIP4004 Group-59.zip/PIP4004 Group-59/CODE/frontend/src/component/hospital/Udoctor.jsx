import React, { useEffect, useState } from "react";
import axios from "axios";
import "../../component/component.css";
import Navbar from "./Navbar";
import { toast, Toaster } from "react-hot-toast";
import { useNavigate, useParams } from "react-router-dom";
import AxiosApi from "../AxiosApi";

const Udoctor = () => {
    const {id}=useParams();
const navigateTo=useNavigate();
  const [formData, setFormData] = useState({
    hospitalName: "",
    name: "",
    email: "",
    password: "",
    qualification: "",
    specialization: "",
    phoneNumber: "",
    address: "",
  });

  const [formErrors, setFormErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    // Clear the error message when the user starts typing in the field
    setFormErrors({ ...formErrors, [name]: "" });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate the form fields before submitting
    const errors = {};
    if (!formData.hospitalName.trim()) {
      errors.hospitalName = "Hospital name is required.";
    }
    if (!formData.name.trim()) {
      errors.name = "Doctor name is required.";
    }
    if (!formData.email.trim()) {
      errors.email = "Email is required.";
    } 
    if (!formData.password.trim()) {
      errors.password = "Password is required.";
    } else if (formData.password.length < 6) {
      errors.password = "Password should be at least 6 characters.";
    }
    if (!formData.qualification.trim()) {
      errors.qualification = "Qualification is required.";
    }
    if (!formData.specialization.trim()) {
      errors.specialization = "Specialization is required.";
    }
    if (!formData.phoneNumber.trim()) {
      errors.phoneNumber = "Phone number is required.";
    } 
    if (!formData.address.trim()) {
      errors.address = "Address is required.";
    }

    if (Object.keys(errors).length === 0) {
      AxiosApi
        .put(`/doctor/doctor/${id}`, formData)
        .then((response) => {
          if (response.data.success === true) {
            toast.success("Doctor updated Successfully");
            navigateTo("/viewDoctors")
          } else {
            toast.error(response.data.msg);
          }
        })
        .catch((error) => {
          toast.error("An error occurred while updating the doctor.");
        });
    } else {
      setFormErrors(errors);
    }
  };
  useEffect(() => {
    // Make an Axios GET request to fetch the list of doctors from your API.
    AxiosApi
      .get("/doctor")
      .then((response) => {
        console.log("API Response:", response.data); // Check the response data
  
        // Check if there are doctors in the response
        if (Array.isArray(response.data.Doctor) && response.data.Doctor.length > 0) {
          const firstDoctor = response.data.Doctor[0]; // Get the data of the first doctor
  
          // Iterate over the properties of the first doctor and set them in formData
          for (const [key, value] of Object.entries(firstDoctor)) {
            setFormData((prevData) => ({
              ...prevData,
              [key]: value,
            }));
          }
        }
      })
      .catch((error) => {
        console.error("API Error:", error);
        // setError("An error occurred while fetching data from the server.");
      });
  }, []);
  return (
    <div>
      <Navbar />
      <div className="pic">
        <div className="wrapper">
          <div className="text-center mt-4 name">Update Doctor</div>
          <form className="p-3 mt-3" onSubmit={handleSubmit}>
            <div className="form-field d-flex align-items-center">
              <span className="far fa-user" />
              <input
                type="text"
                name="hospitalName"
                id="hospitalName"
                placeholder="Enter your hospital name"
                value={formData.hospitalName}
                onChange={handleChange}
              />
            </div>
            {formErrors.hospitalName && (
              <p className="error-text">{formErrors.hospitalName}</p>
            )}

            <div className="form-field d-flex align-items-center">
              <span className="far fa-user" />
              <input
                type="text"
                name="name"
                id="name"
                placeholder="Enter Doctor name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>
            {formErrors.name && <p className="error-text">{formErrors.name}</p>}

            <div className="form-field d-flex align-items-center">
              <span className="far fa-envelope" />
              <input
                type="email"
                name="email"
                id="email"
                placeholder="Enter your email"
                value={formData.email}
                onChange={handleChange}
              />
            </div>
            {formErrors.email && (
              <p className="error-text">{formErrors.email}</p>
            )}

            <div className="form-field d-flex align-items-center">
              <span className="fas fa-key" />
              <input
                type="password"
                name="password"
                id="password"
                placeholder="Password"
                value={formData.password}
                onChange={handleChange}
              />
            </div>
            {formErrors.password && (
              <p className="error-text">{formErrors.password}</p>
            )}

            <div className="form-field d-flex align-items-center">
              <span className="far fa-user" />
              <input
                type="text"
                name="qualification"
                id="qualification"
                placeholder="Enter Doctor qualification"
                value={formData.qualification}
                onChange={handleChange}
              />
            </div>
            {formErrors.qualification && (
              <p className="error-text">{formErrors.qualification}</p>
            )}

            <div className="form-field d-flex align-items-center">
              <span className="far fa-user" />
              <input
                type="text"
                name="specialization"
                id="specialization"
                placeholder="Enter Doctor Specialization"
                value={formData.specialization}
                onChange={handleChange}
              />
            </div>
            {formErrors.specialization && (
              <p className="error-text">{formErrors.specialization}</p>
            )}

            <div className="form-field d-flex align-items-center">
              <span className="fas fa-phone" />
              <input
                type="text"
                name="phoneNumber"
                id="phoneNumber"
                placeholder="Enter your mobile Number (e.g., 123-456-7890)"
                value={formData.phoneNumber}
                onChange={handleChange}
              />
            </div>
            {formErrors.phoneNumber && (
              <p className="error-text">{formErrors.phoneNumber}</p>
            )}

            <div className="form-field d-flex align-items-center">
              <span className="far fa-user" />
              <input
                type="text"
                name="address"
                id="address"
                placeholder="Enter your address"
                value={formData.address}
                onChange={handleChange}
              />
            </div>
            {formErrors.address && (
              <p className="error-text">{formErrors.address}</p>
            )}

            <button type="submit" className="btn mt-3">
              Update Doctor
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Udoctor;
