import React, { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "./Navbar";
import { Link, useNavigate } from "react-router-dom";
import AxiosApi from "../AxiosApi";

function View() {
  const hospitalName=localStorage.getItem("hospitalName");
  const [doctors, setDoctors] = useState([]);
  const [error, setError] = useState(null);
const navigateTo=useNavigate()
  useEffect(() => {
    // Make an Axios GET request to fetch the list of doctors from your API.
    AxiosApi
      .get(`/doctor/hospital/name?hospitalName=${hospitalName}`)
      .then((response) => {
        console.log("API Response:", response.data); // Check the response data
        setDoctors(response.data.Doctor);
      })
      .catch((error) => {
        console.error("API Error:", error);
        setError("An error occurred while fetching data from the server.");
      });
  }, []);

  const handleDeleteClick = (doctorId) => {
    AxiosApi
      .delete(`/doctor/${doctorId}`)
      .then((response) => {
        console.log("Doctor deleted successfully:", response.data);
        setDoctors((prevDoctors) =>
          prevDoctors.filter((doctor) => doctor.id !== doctorId)
        );
      })
      .catch((error) => {
        console.error("Error deleting doctor:", error);
        setError("An error occurred while deleting the doctor.");
      });
  };
const updateFucntion=(id)=>{
navigateTo(`/updateDoctor/${id}`)
}
  return (
    <div>
      <Navbar />
      <div className="container">
        <h2>View Doctors</h2>
        {error && <div className="alert alert-danger">{error}</div>}
        <div className="row">
          {doctors.map((doctor) => (
            <div className="col-md-4" key={doctor.id}>
              <div className="card mb-4">
                <div className="card-body">
                  <p className="card-text">
                    <strong>Hospital Name:</strong> {doctor.hospitalName}
                  </p>
                  <p className="card-text">
                    <strong>Doctor Name:</strong> {doctor.name}
                  </p>
                  <p className="card-text">
                    <strong>Email:</strong> {doctor.email}
                  </p>
                  <p className="card-text">
                    <strong>Qualification:</strong> {doctor.qualification}
                  </p>
                  <p className="card-text">
                    <strong>Specialization:</strong> {doctor.specialization}
                  </p>
                  <p className="card-text">
                    <strong>Phone Number:</strong> {doctor.phoneNumber}
                  </p>
                  <p className="card-text">
                    <strong>Address:</strong> {doctor.address}
                  </p>
                  <div className="btn-group">
                    <div className="doctor-card">
                      <button className="btn btn-warning" onClick={()=>updateFucntion(doctor.id)}
                      >
                        <Link  className="text-decoration-none text-dark">update</Link>
                        </button>
                    </div>
                    <div className="doctor-card">
                      <button
                        className="btn btn-danger"
                        onClick={() => handleDeleteClick(doctor.id)} // Pass the doctor ID to the delete function
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default View;
