import React from 'react'
import PatientNavbar from './PatientNavbar'
import Footer from '../Footer'
import ViewAllDoctors from './ViewAllDoctors'

const PatientHome = () => {
  return (
    <div className='dpic'>
        <PatientNavbar/>
      <ViewAllDoctors/>
        <Footer/>
      
    </div>
  )
}

export default PatientHome