import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import AxiosApi from '../AxiosApi';

const PatientNavbar = () => { const [searchTerm, setSearchTerm] = useState('');
const [searchResults, setSearchResults] = useState([]);
const navigateTo=useNavigate();
const handleSearchChange = (event) => {
  setSearchTerm(event.target.value);
};

const handleSearchSubmit = (event) => {
  event.preventDefault();

  // Replace 'your_api_endpoint_here' with your actual backend API endpoint for searching doctors
  AxiosApi.get(`/doctor/specialization?specialization=${searchTerm}`)
    .then((response) => {
      console.log(response, "searchparr");
     setSearchResults(response.data.Doctors);
    })
    .catch((error) => {
      console.error('Error searching for doctors:', error);
    });
};
const bookAppointmentFucntion=(name,id)=>{
  navigateTo(`/appointment/${name}/${id}`)
  }
  return (
    <div className=''>
          <nav className="navbar navbar-expand-lg bg-body-tertiary fixed-top ">
      <div className="container-fluid" style={{ height: "10px" }}>
        PATIENT
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarScroll"
          aria-controls="navbarScroll"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
      
        <div className="collapse navbar-collapse" id="navbarScroll">  
          <ul
            className="navbar-nav ml-auto my-2 p-2 navbar-nav-scroll ms-auto"
            style={{ "--bs-scroll-height": "100px;" }}
          >
            <form className="d-flex" role="search" onSubmit={handleSearchSubmit}>
        <input className="form-control me-2" type="search" placeholder="Search for doctor"
         aria-label="Search"
         value={searchTerm}
         onChange={handleSearchChange}/>
        <button className="btn btn-outline-success me-5 " type="submit">Search</button>
      </form>
            <li className="nav-item p-2 ">
              <Link to="/phome" className="text-decoration-none text-dark">Home</Link>
            </li>
            <li className="nav-item p-2">
              <Link to="/booked" className="text-decoration-none text-dark">Appointments</Link>
            </li>
            {/* <li className="nav-item p-2">
            <Link to="/appointment" className="text-decoration-none text-dark">Book Appintments</Link>
            </li> */}
            <li className="nav-item p-2">
                <Link to="/" className="text-decoration-none text-dark">Logout</Link>
                </li>
          </ul>
        </div>
      </div>
    </nav>
    <div className="container">
      <div className="row">

      
    {searchResults&&searchResults.map((doctor) => (
              <div className="col-md mt-3" key={doctor.id}>
              <div className="card mb-4">
                <div className="card-body">
                  <p className="card-text">
                    <strong>Hospital Name:</strong> {doctor.hospitalName}
                  </p>
                  <p className="card-text">
                    <strong>Doctor Name:</strong> {doctor.name}
                  </p>
                  <p className="card-text">
                    <strong>Email:</strong> {doctor.email}
                  </p>
                  <p className="card-text">
                    <strong>Qualification:</strong> {doctor.qualification}
                  </p>
                  <p className="card-text">
                    <strong>Specialization:</strong> {doctor.specialization}
                  </p>
                  <p className="card-text">
                    <strong>Phone Number:</strong> {doctor.phoneNumber}
                  </p>
                  <p className="card-text">
                    <strong>Address:</strong> {doctor.address}
                  </p>
                  <div className="btn-group">
                    <div className="doctor-card">
                      <button className="btn btn-warning" onClick={()=>bookAppointmentFucntion(doctor.name, doctor.id)}
                      >
                        <Link  className="text-decoration-none text-dark">Book Appointment</Link>
                        </button>
                    </div>
                    <div className="doctor-card">
                     
                    </div>
                  </div>
                </div>
              </div>
            </div>
            ))}
    </div></div>
    </div>
  )
}

export default PatientNavbar