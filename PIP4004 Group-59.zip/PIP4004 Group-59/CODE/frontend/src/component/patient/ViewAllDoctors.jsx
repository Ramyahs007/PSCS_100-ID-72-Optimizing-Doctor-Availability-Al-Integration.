import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AxiosApi from "../AxiosApi";
import PatientNavbar from "./PatientNavbar";

function ViewAllDoctors() {
  const [doctors, setDoctors] = useState([]);
  const [error, setError] = useState(null);
const navigateTo=useNavigate()
  useEffect(() => {
    // Make an Axios GET request to fetch the list of doctors from your API.
    AxiosApi
      .get("/doctor")
      .then((response) => {
        console.log("API Response:", response.data); // Check the response data
        setDoctors(response.data.Doctor);
      })
      .catch((error) => {
        console.error("API Error:", error);
        setError("An error occurred while fetching data from the server.");
      });
  }, []);

  
const bookAppointmentFucntion=(name,id)=>{
navigateTo(`/appointment/${name}/${id}`)
}
  return (
    <div>
      <PatientNavbar/>
      <div className="container">
        <h2>View Doctors</h2>
        {error && <div className="alert alert-danger">{error}</div>}
        <div className="row">
          {doctors.map((doctor) => (
            <div className="col-md-4" key={doctor.id}>
              <div className="card mb-4">
                <div className="card-body">
                  <p className="card-text">
                    <strong>Hospital Name:</strong> {doctor.hospitalName}
                  </p>
                  <p className="card-text">
                    <strong>Doctor Name:</strong> {doctor.name}
                  </p>
                  <p className="card-text">
                    <strong>Email:</strong> {doctor.email}
                  </p>
                  <p className="card-text">
                    <strong>Qualification:</strong> {doctor.qualification}
                  </p>
                  <p className="card-text">
                    <strong>Specialization:</strong> {doctor.specialization}
                  </p>
                  <p className="card-text">
                    <strong>Phone Number:</strong> {doctor.phoneNumber}
                  </p>
                  <p className="card-text">
                    <strong>Address:</strong> {doctor.address}
                  </p>
                  <div className="btn-group">
                    <div className="doctor-card">
                      <button className="btn btn-warning" onClick={()=>bookAppointmentFucntion(doctor.name, doctor.id)}
                      >
                        <Link  className="text-decoration-none text-dark">Book Appointment</Link>
                        </button>
                    </div>
                    <div className="doctor-card">
                     
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default ViewAllDoctors;
