import { Axios } from 'axios'
import React, { useEffect, useState } from 'react'
import AxiosApi from '../AxiosApi'
import PatientNavbar from './PatientNavbar';

const ViewAppointments = () => {
    const id=localStorage.getItem("pId");
    const [appointments , setAppointments]=useState()
    const getAppointments=async()=>{
       try {
        await AxiosApi.get(`/appointment/patient/${id}`).then((response)=>{
            setAppointments(response.data)
            console.log(response.data, "all appointments");
        })
       } catch (error) {
        console.log(error);
       }
    }
    useEffect(()=>{
getAppointments();
    }, [])
  return (
    <div>
        <PatientNavbar/>
        <table className='table table-bordered table-info  mt-5 '>
            <thead>
                <tr><th colSpan={5} >All Appointments</th></tr>
                <tr>
                    <td>#</td>
                    <td>Doctor Name</td>
            
                    <td>Health Issues</td>
                    <td>Date</td>
                    <td>Status</td>
                </tr>
            </thead>
            <tbody>
                {appointments&&appointments.map((item, index)=>(
                    <tr key={item.id}>
<td>{index+1}</td>

<td>{item.doctorName}</td>
<td>{item.problem}</td>
<td>{item.appointmentDate}</td>
<td>{item.status}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
  )
}

export default ViewAppointments